# chat-sockets-threads-java
Sencillo ejemplo de un chat utilizando sockets y threads en Java
